from typing import Dict, List

import spacy

from utils.logging_config import get_logger

log = get_logger("entity_check")

# Entity types we treat as "subjects" worth checking the order of —
# teams, organisations, people, and places are the most common nouns
# whose RELATIVE ORDER carries factual meaning (e.g. "X beat Y" vs "Y beat X").
_RELEVANT_LABELS = {"ORG", "PERSON", "GPE", "NORP"}


def _entity_sequence(doc: spacy.tokens.Doc) -> List[str]:
    """Return relevant named entities in the order they appear in the text."""
    return [ent.text.strip() for ent in doc.ents if ent.label_ in _RELEVANT_LABELS]


def check_entity_order(nlp: spacy.Language, claim: str, evidence_snippets: List[str]) -> Dict:
    """
    Heuristic contradiction check: if a claim and a piece of web evidence both
    mention the SAME two named entities but in REVERSED order, flag a likely
    swap (e.g. claim says "Team A beat Team B" but evidence says "Team B beat
    Team A" — both contain the same two team names, so naive keyword-overlap
    corroboration would wrongly mark the claim as 'verified' either way).

    This does NOT do full fact verification — it only catches the specific,
    common failure mode of swapped subject/object entities in short claims
    like sports results, election outcomes, or "X did Y to Z" statements.
    """
    log.debug(f"check_entity_order() called | claim preview: {claim[:80]!r}")

    claim_doc = nlp(claim)
    claim_entities = _entity_sequence(claim_doc)

    if len(claim_entities) < 2:
        log.debug("Fewer than 2 relevant entities in claim — skipping order check")
        return {
            "order_mismatch": False,
            "detail": "Not enough named entities in the claim to compare order",
            "claim_entities": claim_entities,
        }

    for snippet in evidence_snippets:
        if not snippet or not snippet.strip():
            continue

        snippet_doc = nlp(snippet)
        snippet_entities = _entity_sequence(snippet_doc)

        # Only compare when the snippet mentions at least the same two entities
        common = [e for e in claim_entities if e in snippet_entities]
        if len(common) < 2:
            continue

        claim_order = [e for e in claim_entities if e in common][:2]
        snippet_order = [e for e in snippet_entities if e in common][:2]

        if claim_order != snippet_order:
            log.warning(
                f"Entity ORDER MISMATCH detected | claim order={claim_order} | "
                f"evidence order={snippet_order} | snippet preview: {snippet[:100]!r}"
            )
            return {
                "order_mismatch": True,
                "detail": (
                    f"Claim mentions {claim_order[0]!r} before {claim_order[1]!r}, "
                    f"but web evidence mentions them in the opposite order — "
                    f"possible factual swap"
                ),
                "claim_entities": claim_entities,
            }

    log.debug("No entity-order mismatch found against any evidence snippet")
    return {
        "order_mismatch": False,
        "detail": "No entity-order mismatch found",
        "claim_entities": claim_entities,
    }


def check_entity_order_for_claims(
    nlp: spacy.Language,
    claims: List[str],
    web_results: List[Dict],
) -> List[Dict]:
    """
    Run check_entity_order() for each (claim, web evidence) pair.
    web_results must be the same length/order as claims (as produced by web_verify_claims).
    """
    log.debug(f"check_entity_order_for_claims() called | {len(claims)} claim(s)")
    results = []
    for claim, web_result in zip(claims, web_results):
        snippets = [ev.get("snippet", "") for ev in web_result.get("evidence", [])]
        snippets += [ev.get("title", "") for ev in web_result.get("evidence", [])]
        result = check_entity_order(nlp, claim, snippets)
        result["claim"] = claim
        results.append(result)

    mismatches = sum(1 for r in results if r["order_mismatch"])
    if mismatches:
        log.info(f"check_entity_order_for_claims() found {mismatches}/{len(claims)} order mismatch(es)")
    else:
        log.debug("check_entity_order_for_claims() found no mismatches")

    return results
